---
name: docx-formatting-template
title: DOCX 默认模板排版
description: 生成符合中国学术/技术文档标准的 Word 文档（.docx），使用 python-docx 实现。包含页面设置、字体规范、多级标题编号、表格/图题自动编号与交叉引用、公式编号、正文样式等完整排版控制。当需要生成正式的中文技术报告、项目计划、提纲文档，或需要对已有 .docx 文档进行格式化排版时使用。
---

# DOCX 中文排版技能

本技能提供一套完整的 python-docx 工具函数和脚本，用于生成符合中国学术/技术文档标准的 Word 文档。

## 使用方式

### 1. 引用现成脚本

有两个可直接使用的完整脚本作为参考：

- `scripts/generate_docx.py` — 标准格式的项目工作计划文档生成器
- `scripts/generate_formal.py` — 提纲格式（附页3-4）的项目工作计划文档生成器

使用前先阅读这两个脚本以理解完整的排版模式，然后基于其中的工具函数构建新文档。

### 2. 核心工具函数

所有工具函数在 `generate_docx.py` 和 `generate_formal.py` 中定义。复制这些函数到新文档脚本中即可。

#### 页面设置

```python
for section in doc.sections:
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(3.17)
    section.right_margin = Cm(3.17)
```

#### 字体设置函数

```python
def set_run_font(run, cn_font='\u5b8b\u4f53', en_font='Times New Roman',
                 size=Pt(12), bold=False):
    run.font.size = size
    run.font.name = en_font
    run.font.bold = bold
    rpr = run._element.get_or_add_rPr()
    rpr.rFonts.set(qn('w:eastAsia'), cn_font)
    color_elem = rpr.find(qn('w:color'))
    if color_elem is None:
        color_elem = OxmlElement('w:color')
        rpr.append(color_elem)
    color_elem.set(qn('w:val'), '000000')
    color_elem.set(qn('w:themeColor'), 'text1')
```

#### 多级编号创建

`get_or_create_numbering_id(doc)` — 创建 6 级抽象编号 + 实际编号元素。关键点：
- 后缀必须用 `space`（非 tab）
- 必须先创建 `<w:abstractNum>` 再创建 `<w:num>`
- 编号字号与标题文字字号一致

#### 正文段落

```python
def make_body(text, align=WD_ALIGN_PARAGRAPH.JUSTIFY, indent=True):
    p = doc.add_paragraph()
    run = p.add_run(text)
    set_run_font(run, size=Pt(12), bold=False)
    pf = p.paragraph_format
    pf.alignment = align
    pf.first_line_indent = Pt(24) if indent else Pt(0)
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    return p
```

#### 标题段落

**不能用 `doc.add_heading()`**，必须手动添加编号引用（`numPr` + `numId` + `ilvl`），因为内置方法不会自动关联自建编号。

详见 `make_heading()` 函数在脚本中的实现。

#### SEQ 自动编号字段

用于表格/图题的自动编号，在 Word 中打开后自动更新：

```python
def _add_seq_field(paragraph, label):
    # 构建完整 SEQ 字段：begin -> instrText -> separate -> display -> end
    # instrText: f' SEQ {label} \\\\* ARABIC'
    # 注意 Python 字符串转义：\\\\* 实际写入 \\*
```

每个 run 的 rPr 中设置：TNR + 宋体 + 黑色 + 12pt(24 half-pts)。

#### 带标题的表格

`add_table_with_caption(headers, rows, caption_text)` — 一体式函数：
- 表题：居中、宋体小四(12pt)、1.5倍行距、SEQ 自动编号
- 表体：`table.style = 'Table Grid'`，宋体五号(10.5pt)、单倍行距、居中
- 自动调整：先按内容再按窗口（`tblW type='pct' w='5000'`）
- 所有单元格垂直居中
- 表题添加书签支持交叉引用

详见脚本中的完整实现。

#### 公式编号

公式用单独的 SEQ 字段：
```python
instr.text = ' SEQ \u5f0f \\\\* ARABIC'
```
格式：制表位居中(pos='4680') + `[LaTeX]` + 制表位右对齐(pos='9360') + `(SEQ编号)`

## 格式规范速查

| 元素 | 中文字体 | 英文字体 | 字号 | 加粗 | 对齐 | 行距 | 首行缩进 |
|------|---------|---------|------|------|------|------|---------|
| 一级标题 | 黑体 | Times New Roman | 16pt (三号) | 否 | 左对齐 | 1.5倍 | 无 |
| 二级标题 | 宋体 | Times New Roman | 14pt (四号) | 是 | 左对齐 | 1.5倍 | 无 |
| 三级标题 | 宋体 | Times New Roman | 12pt (小四) | 是 | 左对齐 | 1.5倍 | 无 |
| 正文 | 宋体 | Times New Roman | 12pt (小四) | 否 | 两端对齐 | 1.5倍 | 2字符 |
| 表头 | 宋体 | Times New Roman | 10.5pt (五号) | 是 | 居中 | 单倍 | 无 |
| 表体 | 宋体 | Times New Roman | 10.5pt (五号) | 否 | 居中 | 单倍 | 无 |
| 表题/图题 | 宋体 | Times New Roman | 12pt (小四) | 否 | 居中 | 1.5倍 | 无 |
| 参考文献 | 宋体 | Times New Roman | 10.5pt (五号) | 否 | 两端对齐 | 1.5倍 | 无 |

## 禁则

1. 禁用 emoji — 状态描述使用纯文字替代
2. 全文黑色 — 所有字体颜色为 #000000
3. 英文全 TNR — 任何位置的英文字体都是 Times New Roman

## 数学符号 LaTeX 化

凡是数学变量、符号、上下标，一律用 `$...$` 包裹。

## 段落间距统一规范

| 元素 | space_before | space_after | 行距 |
|------|-------------|-------------|------|
| 正文 | Pt(0) | Pt(0) | 1.5 倍 |
| 标题 | Pt(0) | Pt(0) | 1.5倍 |
| 公式 | Pt(3) | Pt(3) | 单倍 |
| 表题 | Pt(0) | Pt(0) | 1.5 倍 |
| 表体 | Pt(0) | Pt(0) | 单倍 |
| 参考文献 | Pt(0) | Pt(0) | 1.5 倍 |

## 参考脚本

完整的 `scripts/generate_docx.py` 和 `scripts/generate_formal.py` 包含页面设置、字体设置、多级编号定义、正文、标题、SEQ字段、表格自动调整、交叉引用的完整实现，用作格式参考和工具函数来源。

## 用户强制补充规则：中文博士论文式DOCX报告

- 段内不加任何无意义空格：中文正文中不要在中文与英文缩写、变量、数字、单位之间随意加入空格；单位组合写作`1550nm`、`40mW`、`18dB`、`50m`、`0.02dB/m`等，英文缩写与中文词组写作`ARW指标`、`RIN噪声`等。LaTeX公式源码内部为语法或可读性保留的空格除外。
- 正式报告的图题、表题必须使用`SEQ`字段自动编号并加书签；正文引用图表必须使用`REF`字段交叉引用，显示为“图1”“表1”等，不手写固定编号。
- 公式必须是独立公式段落：居中公式源码，右侧制表位放置`(SEQ 式)`自动编号；正文引用写作“式(1)”等，避免把公式和编号混在普通正文段落里。
- 博士论文式技术报告中，公式后必须解释变量定义、单位、物理含义和设计约束意义；仿真图后必须给出趋势、设计点位置、指标裕量和工程判断分析。
