#!/usr/bin/env python
"""
Generate 8.项目下一阶段工作计划.docx with strict formatting.
"""
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from copy import deepcopy
import os

doc = Document()

# ---- Page margins ----
for section in doc.sections:
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(3.17)
    section.right_margin = Cm(3.17)

# ---- Font helper ----
def set_run_font(run, cn_font='\u5b8b\u4f53', en_font='Times New Roman',
                 size=Pt(12), bold=False, color_rgb=None):
    run.font.size = size
    run.font.name = en_font
    run.font.bold = bold
    rpr = run._element.get_or_add_rPr()
    rpr.rFonts.set(qn('w:eastAsia'), cn_font)
    # Color = auto (black)
    color_elem = rpr.find(qn('w:color'))
    if color_elem is None:
        color_elem = OxmlElement('w:color')
        rpr.append(color_elem)
    color_elem.set(qn('w:val'), '000000')
    color_elem.set(qn('w:themeColor'), 'text1')

# ---- Multi-level list numbering ----
def get_or_create_numbering_id(doc):
    numbering_part = doc.part.numbering_part
    numbering_xml = numbering_part._element

    max_abs_id = 0
    for an in numbering_xml.findall(qn('w:abstractNum')):
        aid = int(an.get(qn('w:abstractNumId')))
        if aid >= max_abs_id:
            max_abs_id = aid
    abs_num_id = max_abs_id + 1

    abstract_num = OxmlElement('w:abstractNum')
    abstract_num.set(qn('w:abstractNumId'), str(abs_num_id))

    for ilvl, fmt in enumerate(['%1.', '%1.%2', '%1.%2.%3']):
        lvl = OxmlElement('w:lvl')
        lvl.set(qn('w:ilvl'), str(ilvl))
        lvl_fmt = OxmlElement('w:numFmt')
        lvl_fmt.set(qn('w:val'), 'decimal')
        lvl.append(lvl_fmt)
        lvl_lvlText = OxmlElement('w:lvlText')
        lvl_lvlText.set(qn('w:val'), fmt)
        lvl.append(lvl_lvlText)
        lvl_start = OxmlElement('w:start')
        lvl_start.set(qn('w:val'), '1')
        lvl.append(lvl_start)
        lvl_just = OxmlElement('w:lvlJc')
        lvl_just.set(qn('w:val'), 'left')
        lvl.append(lvl_just)
        # Suffix: space (not tab)
        lvl_suff = OxmlElement('w:suff')
        lvl_suff.set(qn('w:val'), 'space')
        lvl.append(lvl_suff)

        # Font per heading level: 编号字号与标题文字一致
        size_map = {0: 32, 1: 28, 2: 24}  # 三号16pt, 四号14pt, 小四12pt (half-pts)
        en_font = 'Times New Roman'
        cn_font_map = {0: '\u9ed1\u4f53', 1: '\u5b8b\u4f53', 2: '\u5b8b\u4f53'}
        bold_map = {0: False, 1: True, 2: True}
        lvl_rPr = OxmlElement('w:rPr')
        lvl_rFonts = OxmlElement('w:rFonts')
        lvl_rFonts.set(qn('w:ascii'), en_font)
        lvl_rFonts.set(qn('w:hAnsi'), en_font)
        lvl_rFonts.set(qn('w:eastAsia'), cn_font_map[ilvl])
        lvl_rPr.append(lvl_rFonts)
        lvl_color = OxmlElement('w:color')
        lvl_color.set(qn('w:val'), '000000')
        lvl_rPr.append(lvl_color)
        lvl_sz = OxmlElement('w:sz')
        lvl_sz.set(qn('w:val'), str(size_map[ilvl]))
        lvl_rPr.append(lvl_sz)
        lvl_szCs = OxmlElement('w:szCs')
        lvl_szCs.set(qn('w:val'), str(size_map[ilvl]))
        lvl_rPr.append(lvl_szCs)
        if bold_map[ilvl]:
            lvl_b = OxmlElement('w:b')
            lvl_rPr.append(lvl_b)
        lvl.append(lvl_rPr)

        lvl_pPr = OxmlElement('w:pPr')
        lvl_ind = OxmlElement('w:ind')
        lvl_ind.set(qn('w:left'), '0')
        lvl_ind.set(qn('w:hanging'), '0')
        lvl_pPr.append(lvl_ind)
        lvl.append(lvl_pPr)
        abstract_num.append(lvl)

    numbering_xml.append(abstract_num)

    max_num_id = 0
    for n in numbering_xml.findall(qn('w:num')):
        nid = int(n.get(qn('w:numId')))
        if nid >= max_num_id:
            max_num_id = nid
    num_id = max_num_id + 1

    num_elem = OxmlElement('w:num')
    num_elem.set(qn('w:numId'), str(num_id))
    abs_ref = OxmlElement('w:abstractNumId')
    abs_ref.set(qn('w:val'), str(abs_num_id))
    num_elem.append(abs_ref)
    numbering_xml.append(num_elem)

    return num_id

NUM_ID = get_or_create_numbering_id(doc)

# ---- Body paragraph ----
def make_body(text, align=WD_ALIGN_PARAGRAPH.JUSTIFY, indent=True):
    p = doc.add_paragraph()
    run = p.add_run(text)
    set_run_font(run, size=Pt(12), bold=False)
    pf = p.paragraph_format
    pf.alignment = align
    # 段前2字符缩进 = 2 * 12pt = 24pt
    pf.first_line_indent = Pt(24) if indent else Pt(0)
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    return p

# ---- Heading ----
def make_heading(level, text, ilvl):
    style_map = {1: 'Heading 1', 2: 'Heading 2', 3: 'Heading 3'}
    p = doc.add_paragraph()
    p.style = doc.styles[style_map[level]]
    p.clear()

    pPr = p._element.get_or_add_pPr()

    # Numbering
    numPr = OxmlElement('w:numPr')
    numId_el = OxmlElement('w:numId')
    numId_el.set(qn('w:val'), str(NUM_ID))
    numPr.append(numId_el)
    ilvl_el = OxmlElement('w:ilvl')
    ilvl_el.set(qn('w:val'), str(ilvl))
    numPr.append(ilvl_el)
    pPr.append(numPr)

    # Remove existing indent/spacing
    for old in pPr.findall(qn('w:ind')):
        pPr.remove(old)
    for old in pPr.findall(qn('w:spacing')):
        pPr.remove(old)
    for old in pPr.findall(qn('w:jc')):
        pPr.remove(old)

    # Spacing
    spacing = OxmlElement('w:spacing')
    spacing.set(qn('w:before'), '0')
    spacing.set(qn('w:after'), '0')
    spacing.set(qn('w:line'), '360')
    spacing.set(qn('w:lineRule'), 'auto')
    pPr.append(spacing)

    # Left alignment
    jc = OxmlElement('w:jc')
    jc.set(qn('w:val'), 'left')
    pPr.append(jc)

    # Run
    run = p.add_run(text)
    if level == 1:
        set_run_font(run, cn_font='\u9ed1\u4f53', size=Pt(16), bold=False)
    elif level == 2:
        set_run_font(run, size=Pt(14), bold=True)
    else:
        set_run_font(run, size=Pt(12), bold=True)
    return p

# ---- SEQ counter helpers ----
_table_seq = [0]

def _add_seq_field(paragraph, label):
    _table_seq[0] += 1
    seq_num = _table_seq[0]

    def make_r():
        r = OxmlElement('w:r')
        rpr = OxmlElement('w:rPr')
        rFonts = OxmlElement('w:rFonts')
        rFonts.set(qn('w:ascii'), 'Times New Roman')
        rFonts.set(qn('w:hAnsi'), 'Times New Roman')
        rFonts.set(qn('w:eastAsia'), '\u5b8b\u4f53')
        rpr.append(rFonts)
        color_e = OxmlElement('w:color')
        color_e.set(qn('w:val'), '000000')
        color_e.set(qn('w:themeColor'), 'text1')
        rpr.append(color_e)
        sz = OxmlElement('w:sz')
        sz.set(qn('w:val'), '24')  # 12pt
        rpr.append(sz)
        szCs = OxmlElement('w:szCs')
        szCs.set(qn('w:val'), '24')
        rpr.append(szCs)
        r.append(rpr)
        return r

    # begin
    rb = make_r()
    fc = OxmlElement('w:fldChar')
    fc.set(qn('w:fldCharType'), 'begin')
    rb.append(fc)
    paragraph._element.append(rb)

    # instrText
    ri = make_r()
    it = OxmlElement('w:instrText')
    it.set(qn('xml:space'), 'preserve')
    it.text = f' SEQ {label} \\* ARABIC'
    ri.append(it)
    paragraph._element.append(ri)

    # separate
    rs = make_r()
    fcs = OxmlElement('w:fldChar')
    fcs.set(qn('w:fldCharType'), 'separate')
    rs.append(fcs)
    paragraph._element.append(rs)

    # display
    rd = make_r()
    dt = OxmlElement('w:t')
    dt.text = str(seq_num)
    rd.append(dt)
    paragraph._element.append(rd)

    # end
    re = make_r()
    fce = OxmlElement('w:fldChar')
    fce.set(qn('w:fldCharType'), 'end')
    re.append(fce)
    paragraph._element.append(re)

def _add_bookmark(paragraph, name):
    bm_id = str(abs(hash(name)) % 1000000)
    bm_start = OxmlElement('w:bookmarkStart')
    bm_start.set(qn('w:id'), bm_id)
    bm_start.set(qn('w:name'), name)
    paragraph._element.insert(0, bm_start)

    bm_end = OxmlElement('w:bookmarkEnd')
    bm_end.set(qn('w:id'), bm_id)
    paragraph._element.append(bm_end)

# ---- Table with caption ----
def add_table_with_caption(headers, rows, caption_text):
    # Caption paragraph: "表X caption_text" (宋体小四, 1.5倍行距, 居中)
    cap_p = doc.add_paragraph()
    cap_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pf = cap_p.paragraph_format
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.first_line_indent = Pt(0)
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5

    # "表" text run
    r0 = cap_p.add_run('\u8868')
    set_run_font(r0, size=Pt(12), bold=False)

    # SEQ field
    _add_seq_field(cap_p, '\u8868')

    # Space + caption text
    r2 = cap_p.add_run('  ' + caption_text)
    set_run_font(r2, size=Pt(12), bold=False)

    # Bookmark for cross-ref
    bm_name = f'table_{_table_seq[0]}'
    _add_bookmark(cap_p, bm_name)

    # Table
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'

    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = ''
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.first_line_indent = Pt(0)
        p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
        r = p.add_run(h)
        set_run_font(r, size=Pt(10.5), bold=True)

    for ri, row in enumerate(rows):
        for ci, val in enumerate(row):
            cell = table.rows[ri + 1].cells[ci]
            cell.text = ''
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.first_line_indent = Pt(0)
            p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            r = p.add_run(str(val))
            set_run_font(r, size=Pt(10.5), bold=False)

    # ---- Table autofit: content first, then window ----
    table.autofit = True
    tbl = table._tbl
    tblPr = tbl.find(qn('w:tblPr'))
    if tblPr is None:
        tblPr = OxmlElement('w:tblPr')
        tbl.insert(0, tblPr)
    # Layout = autofit
    layout = tblPr.find(qn('w:tblLayout'))
    if layout is None:
        layout = OxmlElement('w:tblLayout')
        tblPr.append(layout)
    layout.set(qn('w:type'), 'autofit')
    # Width = 100% (window)
    tblW = tblPr.find(qn('w:tblW'))
    if tblW is None:
        tblW = OxmlElement('w:tblW')
        tblPr.append(tblW)
    tblW.set(qn('w:type'), 'pct')
    tblW.set(qn('w:w'), '5000')

    # ---- Vertical center for all cells ----
    for row_obj in table.rows:
        for cell_obj in row_obj.cells:
            tc = cell_obj._tc
            tcPr = tc.find(qn('w:tcPr'))
            if tcPr is None:
                tcPr = OxmlElement('w:tcPr')
                tc.insert(0, tcPr)
            vAlign = OxmlElement('w:vAlign')
            vAlign.set(qn('w:val'), 'center')
            tcPr.append(vAlign)

    # Spacer
    sp = doc.add_paragraph()
    sp.paragraph_format.space_before = Pt(0)
    sp.paragraph_format.space_after = Pt(0)
    sp.paragraph_format.first_line_indent = Pt(0)
    sp.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    sp.paragraph_format.line_spacing = 1.5

    return table

# ============================================================
# DOCUMENT CONTENT
# ============================================================

# Title
tp = doc.add_paragraph()
tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
tp.paragraph_format.space_before = Pt(0)
tp.paragraph_format.space_after = Pt(12)
tp.paragraph_format.first_line_indent = Pt(0)
tp.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
tp.paragraph_format.line_spacing = 1.5
r = tp.add_run('8. \u9879\u76ee\u4e0b\u4e00\u9636\u6bb5\u5de5\u4f5c\u8ba1\u5212')
set_run_font(r, cn_font='\u9ed1\u4f53', size=Pt(22), bold=True)

sp2 = doc.add_paragraph()
sp2.alignment = WD_ALIGN_PARAGRAPH.CENTER
sp2.paragraph_format.space_before = Pt(0)
sp2.paragraph_format.space_after = Pt(6)
sp2.paragraph_format.first_line_indent = Pt(0)
sp2.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
sp2.paragraph_format.line_spacing = 1.5
r = sp2.add_run('\u8bfe\u98981\uff1a\u57fa\u4e8e\u7845\u5149\u6280\u672f\u7684\u9ad8\u7cbe\u5ea6\u89d2\u901f\u5ea6\u6d4b\u91cf\u7406\u8bba\uff082024YFB3212701\uff09')
set_run_font(r, size=Pt(14))

doc.add_paragraph()

# ===== 1 =====
make_heading(1, '\u603b\u4f53\u76ee\u6807', 0)
make_body('\u8bfe\u9898\u6267\u884c\u671f\u4e3a2024\u5e7412\u6708\u81f32027\u5e7411\u6708\u3002\u622a\u81f3\u4e2d\u671f\u68c0\u67e5\u8282\u70b9\uff082026\u5e746\u6708\uff09\uff0c\u8bfe\u9898\u5df2\u6309\u8ba1\u5212\u5b8c\u6210\u5168\u90e8\u4e2d\u671f\u7814\u7a76\u4efb\u52a1\uff0c\u5e76\u8d85\u524d\u5b8c\u6210\u90e8\u5206\u7ed3\u9898\u6307\u6807\u3002\u4e0b\u4e00\u9636\u6bb5\u7684\u5de5\u4f5c\u91cd\u5fc3\u5c06\u4ece\u8bef\u5dee\u5efa\u6a21\u4e0e\u7406\u8bba\u5206\u6790\u8f6c\u5411\u6a21\u578b\u9a8c\u8bc1\u4f18\u5316\u3001\u8bef\u5dee\u6291\u5236\u65b9\u6cd5\u5de5\u7a0b\u5316\u9a8c\u8bc1\u4ee5\u53ca\u79d1\u7814\u6210\u679c\u4ea7\u51fa\uff0c\u786e\u4fdd2027\u5e7411\u6708\u9ad8\u8d28\u91cf\u5b8c\u6210\u8bfe\u9898\u7ed3\u9898\u9a8c\u6536\u3002')

# ===== 2 =====
make_heading(1, '\u4e2d\u671f\u5df2\u53d6\u5f97\u7684\u4e3b\u8981\u8fdb\u5c55', 0)
make_body('\u4e2d\u671f\u5df2\u53d6\u5f97\u7684\u4e3b\u8981\u8fdb\u5c55\u89c1\u88681\u3002')

add_table_with_caption(
    ['\u5e8f\u53f7', '\u4efb\u52a1\u5185\u5bb9', '\u5b8c\u6210\u72b6\u6001', '\u8bf4\u660e'],
    [
        ['1', '\u5fae\u578b\u7845\u5149\u9640\u87ba\u7cbe\u5bc6\u6d4b\u91cf\u6a21\u578b\u4eff\u771f\u8f6f\u4ef6\u5f00\u53d1', '\u5df2\u5b8c\u6210', '\u652f\u63016\u79cd\u8bef\u5dee\u7c7b\u522b\u4eff\u771f\uff0c\u901a\u8fc7\u4e13\u5bb6\u73b0\u573a\u6d4b\u8bd5'],
        ['2', '\u6b7b\u533a\u8bef\u5dee\uff08Dead Zone\uff09\u6a21\u578b', '\u5df2\u8d85\u524d\u5b8c\u6210', '\u5df2\u96c6\u6210\u81f3\u4eff\u771f\u8f6f\u4ef6\uff0c\u652f\u63017\u79cd\u8bef\u5dee\u7c7b\u522b'],
        ['3', '\u566a\u58f0\u5206\u6790\u53ca\u6291\u5236\u62a5\u544a', '\u5df2\u5b8c\u6210', '\u6db5\u76d66\u7c7b\u566a\u58f0\u7684\u7406\u8bba\u5efa\u6a21\u4e0e\u6291\u5236\u65b9\u6848'],
        ['4', '\u4eff\u771f\u8f6f\u4ef6\u8457\u4f5c\u6743', '\u5df2\u5b8c\u6210', '\u5df2\u53d6\u5f97\u8f6f\u4ef6\u8457\u4f5c\u6743\u8bc1\u4e66'],
        ['5', '\u53d1\u660e\u4e13\u5229', '\u6301\u7eed\u63a8\u8fdb\u4e2d', '\u5df2\u8fdb\u5165\u5b9e\u8d28\u5ba1\u67e5\u9636\u6bb5'],
    ],
    '\u4e2d\u671f\u5df2\u53d6\u5f97\u7684\u4e3b\u8981\u8fdb\u5c55'
)

# ===== 3 =====
make_heading(1, '\u4e0b\u4e00\u9636\u6bb5\u5de5\u4f5c\u8ba1\u5212', 0)

# 3.1
make_heading(2, '\u8bef\u5dee\u6a21\u578b\u7684\u7cbe\u5ea6\u9a8c\u8bc1\u4e0e\u8fed\u4ee3\u4f18\u5316', 1)
make_body('\u76ee\u6807\uff1a\u786e\u4fdd\u4eff\u771f\u8f6f\u4ef6\u8ba1\u7b97\u7ed3\u679c\u4e0e\u8bfe\u98985\u539f\u7406\u6837\u673a\u5b9e\u6d4b\u7ed3\u679c\u7684\u4e00\u81f4\u6027\uff0c\u76f8\u5bf9\u8bef\u5dee\u226410%\u3002')
add_table_with_caption(
    ['\u5de5\u4f5c\u5185\u5bb9', '\u65f6\u95f4\u8282\u70b9', '\u4ea4\u4ed8\u7269'],
    [
        ['\u4e0e\u8bfe\u98985\u5bf9\u63a5\uff0c\u83b7\u53d6\u539f\u7406\u6837\u673a\u5b9e\u6d4b\u6570\u636e', '2026\u5e747\u6708', '\u5b9e\u6d4b\u6570\u636e\u6e05\u5355'],
        ['\u57fa\u4e8e\u5b9e\u6d4b\u6570\u636e\u8c03\u6574\u4eff\u771f\u53c2\u6570\uff0c\u5f00\u5c55\u6a21\u578b\u6821\u51c6', '2026\u5e748\u6708\uff5e9\u6708', '\u6821\u51c6\u8bb0\u5f55'],
        ['\u5f00\u5c557\u79cd\u8bef\u5dee\u7c7b\u522b\u7684\u4eff\u771f-\u5b9e\u6d4b\u6bd4\u5bf9\u9a8c\u8bc1', '2026\u5e7410\u6708\uff5e11\u6708', '\u6bd4\u5bf9\u5206\u6790\u62a5\u544a'],
        ['\u82e5\u8bef\u5dee\u8d85\u9650\uff0c\u8fed\u4ee3\u4f18\u5316\u6a21\u578b\u7b97\u6cd5', '2026\u5e7411\u6708\uff5e12\u6708', '\u4f18\u5316\u540e\u7684\u6a21\u578b'],
        ['\u5b8c\u6210\u5fae\u578b\u7845\u5149\u9640\u87ba\u7cbe\u5bc6\u6d4b\u91cf\u6a21\u578b\u62a5\u544a', '2026\u5e7412\u6708', '\u62a5\u544a\u6b63\u6587\uff08\u901a\u8fc7\u4e13\u5bb6\u8bc4\u5ba1\uff09'],
    ],
    '\u8bef\u5dee\u6a21\u578b\u7684\u7cbe\u5ea6\u9a8c\u8bc1\u4e0e\u8fed\u4ee3\u4f18\u5316\u5de5\u4f5c\u8ba1\u5212'
)

# 3.2
make_heading(2, '\u566a\u58f0\u6291\u5236\u65b9\u6cd5\u7684\u5de5\u7a0b\u5316\u9a8c\u8bc1', 1)
make_body('\u76ee\u6807\uff1a\u5c06\u566a\u58f0\u5206\u6790\u53ca\u6291\u5236\u62a5\u544a\u4e2d\u7684\u7406\u8bba\u65b9\u6848\u5e94\u7528\u5230\u8bfe\u98985\u539f\u7406\u6837\u673a\uff0c\u5b9a\u91cf\u8bc4\u4f30\u6291\u5236\u6548\u679c\u3002')
add_table_with_caption(
    ['\u5de5\u4f5c\u5185\u5bb9', '\u65f6\u95f4\u8282\u70b9', '\u4ea4\u4ed8\u7269'],
    [
        ['\u6563\u7c92\u566a\u58f0\u3001\u70ed\u566a\u58f0\u3001RIN\u6291\u5236\u65b9\u6848\u5b9e\u65bd\u4e0e\u9a8c\u8bc1', '2026\u5e747\u6708\uff5e9\u6708', '\u6d4b\u8bd5\u6570\u636e'],
        ['\u504f\u632f\u8026\u5408\u6291\u5236\u65b9\u6848\uff08\u4f18\u5316\u6ce2\u5bfch\u53c2\u6570\u3001\u504f\u632f\u6d88\u5149\u6bd4\uff09\u5b9e\u65bd\u4e0e\u9a8c\u8bc1', '2026\u5e7410\u6708\uff5e12\u6708', '\u6d4b\u8bd5\u6570\u636e'],
        ['\u80cc\u5411\u6563\u5c04\u6291\u5236\u65b9\u6848\uff08\u4f18\u5316\u5206\u5149\u6bd4\u3001\u6ce2\u5bfc\u635f\u8017\uff09\u5b9e\u65bd\u4e0e\u9a8c\u8bc1', '2027\u5e741\u6708\uff5e3\u6708', '\u6d4b\u8bd5\u6570\u636e'],
        ['\u514b\u5c14\u6548\u5e94\u6291\u5236\u65b9\u6848\uff08\u95ed\u73af\u89e3\u8c03\u3001\u4f18\u5316\u8c03\u5236\u6df1\u5ea6\uff09\u5b9e\u65bd\u4e0e\u9a8c\u8bc1', '2027\u5e744\u6708\uff5e6\u6708', '\u6d4b\u8bd5\u6570\u636e'],
        ['\u6c47\u603b\u5404\u6291\u5236\u65b9\u6cd5\u7684\u6548\u679c\uff0c\u5b8c\u6210\u566a\u58f0\u6291\u5236\u6548\u679c\u8bc4\u4f30\u62a5\u544a', '2027\u5e746\u6708', '\u566a\u58f0\u6291\u5236\u6548\u679c\u7efc\u5408\u62a5\u544a'],
    ],
    '\u566a\u58f0\u6291\u5236\u65b9\u6cd5\u7684\u5de5\u7a0b\u5316\u9a8c\u8bc1\u5de5\u4f5c\u8ba1\u5212'
)

# 3.3
make_heading(2, '\u79d1\u7814\u6210\u679c\u4ea7\u51fa', 1)
make_body('\u76ee\u6807\uff1a\u5b8c\u6210\u7ed3\u9898\u6307\u6807\u8981\u6c42\u76846\u9879\u53d1\u660e\u4e13\u5229\u30016\u7bc7SCI/EI/\u6838\u5fc3\u8bba\u6587\u3001\u22653\u540d\u7814\u7a76\u751f\u57f9\u517b\u3002')

make_heading(3, '\u53d1\u660e\u4e13\u5229', 2)
add_table_with_caption(
    ['\u5e8f\u53f7', '\u4e13\u5229\u540d\u79f0\uff08\u62df\uff09', '\u8ba1\u5212\u63d0\u4ea4\u65f6\u95f4', '\u72b6\u6001'],
    [
        ['1', '\u5df2\u63d0\u4ea4\uff08\u5b9e\u8d28\u5ba1\u67e5\u4e2d\uff09', '\u5df2\u63d0\u4ea4', '\u5b9e\u8d28\u5ba1\u67e5'],
        ['2\uff5e4', '\u56f4\u7ed5\u504f\u632f\u8026\u5408\u6291\u5236\u3001\u80cc\u5411\u6563\u5c04\u6291\u5236\u3001\u6b7b\u533a\u8bef\u5dee\u8865\u507f', '2026\u5e749\u6708\u524d', '\u51c6\u5907\u4e2d'],
        ['5\uff5e6', '\u56f4\u7ed5\u7845\u5149\u9640\u87ba\u7cfb\u7edf\u8bbe\u8ba1\u4f18\u5316\u3001\u4eff\u771f\u65b9\u6cd5', '2027\u5e743\u6708\u524d', '\u51c6\u5907\u4e2d'],
    ],
    '\u53d1\u660e\u4e13\u5229\u8ba1\u5212'
)

make_heading(3, '\u5b66\u672f\u8bba\u6587', 2)
add_table_with_caption(
    ['\u5e8f\u53f7', '\u8bba\u6587\u65b9\u5411\uff08\u62df\uff09', '\u8ba1\u5212\u6295\u7a3f\u65f6\u95f4', '\u76ee\u6807\u671f\u520a'],
    [
        ['1', '\u5bbd\u8c31\u5149\u6e90\u76f8\u5bf9\u5f3a\u5ea6\u566a\u58f0\u7406\u8bba\u4e0e\u5efa\u6a21', '2026\u5e749\u6708', 'Optics Express / \u5149\u5b66\u5b66\u62a5'],
        ['2', '\u5fae\u578b\u7845\u5149\u9640\u87ba\u504f\u632f\u8026\u5408\u8bef\u5dee\u5206\u6790\u4e0e\u6291\u5236', '2026\u5e7412\u6708', 'Journal of Lightwave Technology'],
        ['3', '\u5fae\u578b\u7845\u5149\u9640\u87ba\u80cc\u5411\u6563\u5c04\u566a\u58f0\u6a21\u578b\u7814\u7a76', '2027\u5e743\u6708', 'IEEE Photonics Journal'],
        ['4', '\u5fae\u578b\u7845\u5149\u9640\u87ba\u6b7b\u533a\u6548\u5e94\u673a\u7406\u4e0e\u5efa\u6a21', '2027\u5e746\u6708', '\u5149\u5b66\u7cbe\u5bc6\u5de5\u7a0b / Sensors'],
        ['5', '\u514b\u5c14\u6548\u5e94\u5bf9\u7845\u5149\u9640\u87ba\u96f6\u504f\u7a33\u5b9a\u6027\u7684\u5f71\u54cd\u7814\u7a76', '2027\u5e749\u6708', 'Photonics / \u5149\u5b50\u5b66\u62a5'],
        ['6', '\u5fae\u578b\u7845\u5149\u9640\u87ba\u591a\u6e90\u8bef\u5dee\u8026\u5408\u5efa\u6a21\u4e0e\u6027\u80fd\u9884\u6d4b', '2027\u5e749\u6708', 'Optics and Laser Technology'],
    ],
    '\u5b66\u672f\u8bba\u6587\u8ba1\u5212'
)

make_heading(3, '\u7814\u7a76\u751f\u57f9\u517b', 2)
add_table_with_caption(
    ['\u59d3\u540d', '\u7814\u7a76\u65b9\u5411', '\u8ba1\u5212\u6bd5\u4e1a\u65f6\u95f4', '\u72b6\u6001'],
    [['\uff08\u4e2d\u671f\u68c0\u67e5\u5df2\u63d0\u4f9b\u7684\u22653\u540d\u535a\u58eb\u751f\u540d\u5355\uff09', '\u5fae\u578b\u7845\u5149\u9640\u87ba\u8bef\u5dee\u5efa\u6a21\u4e0e\u6291\u5236', '2027\u5e7411\u6708\u524d', '\u5728\u57f9']],
    '\u7814\u7a76\u751f\u57f9\u517b\u8ba1\u5212'
)

# 3.4
make_heading(2, '\u4eff\u771f\u8f6f\u4ef6\u529f\u80fd\u5b8c\u5584\u4e0e\u7ed3\u9898\u6d4b\u8bd5', 1)
make_body('\u76ee\u6807\uff1a\u5b8c\u6210\u5168\u90777\u79cd\u8bef\u5dee\u7c7b\u522b\u7684\u7ed3\u9898\u6d4b\u8bd5\uff0c\u786e\u4fdd\u8f6f\u4ef6\u529f\u80fd\u5b8c\u5907\u3001\u7ed3\u679c\u51c6\u786e\u3002')
add_table_with_caption(
    ['\u5de5\u4f5c\u5185\u5bb9', '\u65f6\u95f4\u8282\u70b9', '\u4ea4\u4ed8\u7269'],
    [
        ['\u5b8c\u5584\u4eff\u771f\u8f6f\u4ef6\u754c\u9762\u4e0e\u7528\u6237\u4f53\u9a8c', '2027\u5e747\u6708', '\u66f4\u65b0\u540e\u7684\u4eff\u771f\u8f6f\u4ef6'],
        ['\u7f16\u5199\u7ed3\u9898\u6d4b\u8bd5\u62a5\u544a', '2027\u5e748\u6708', '\u7ed3\u9898\u6d4b\u8bd5\u62a5\u544a'],
        ['\u914d\u5408\u4e13\u5bb6\u73b0\u573a\u6d4b\u8bd5', '2027\u5e749\u6708', '\u73b0\u573a\u6d4b\u8bd5\u8bb0\u5f55'],
        ['\u5b8c\u6210\u8bfe\u9898\u7ed3\u9898\u9a8c\u6536\u6750\u6599\u6c47\u603b', '2027\u5e7410\u6708', '\u5168\u90e8\u7ed3\u9898\u6750\u6599'],
    ],
    '\u4eff\u771f\u8f6f\u4ef6\u529f\u80fd\u5b8c\u5584\u4e0e\u7ed3\u9898\u6d4b\u8bd5\u5de5\u4f5c\u8ba1\u5212'
)

# 3.5
make_heading(2, '\u7ed3\u9898\u9a8c\u6536\u51c6\u5907', 1)
add_table_with_caption(
    ['\u5de5\u4f5c\u5185\u5bb9', '\u65f6\u95f4\u8282\u70b9', '\u4ea4\u4ed8\u7269'],
    [
        ['\u6c47\u603b\u8bfe\u9898\u6267\u884c\u60c5\u51b5\u62a5\u544a', '2027\u5e7410\u6708', '\u8bfe\u9898\u6267\u884c\u60c5\u51b5\u62a5\u544a'],
        ['\u6c47\u603b\u77e5\u8bc6\u4ea7\u6743\u6e05\u5355', '2027\u5e7410\u6708', '\u4e13\u5229/\u8bba\u6587/\u8f6f\u8457\u6e05\u5355'],
        ['\u8d22\u52a1\u51b3\u7b97\u4e0e\u5ba1\u8ba1\u914d\u5408', '2027\u5e7410\u6708\uff5e11\u6708', '\u8d22\u52a1\u51b3\u7b97\u62a5\u544a'],
        ['\u7ed3\u9898\u7b54\u8fa9\u51c6\u5907', '2027\u5e7411\u6708', '\u7b54\u8fa9PPT\u53ca\u5168\u5957\u6750\u6599'],
    ],
    '\u7ed3\u9898\u9a8c\u6536\u51c6\u5907\u5de5\u4f5c\u8ba1\u5212'
)

# ===== 4 =====
make_heading(1, '\u9636\u6bb5\u6027\u91cc\u7a0b\u7891', 0)
make_body('\u4e0b\u4e00\u9636\u6bb5\u7684\u5173\u952e\u91cc\u7a0b\u7891\u8282\u70b9\u89c1\u88682\u3002')
add_table_with_caption(
    ['\u91cc\u7a0b\u7891', '\u5b8c\u6210\u65f6\u95f4', '\u5173\u952e\u4ea4\u4ed8\u7269'],
    [
        ['M1\uff1a\u6a21\u578b\u7cbe\u5ea6\u9a8c\u8bc1\u5b8c\u6210', '2026\u5e7412\u6708', '\u5fae\u578b\u7845\u5149\u9640\u87ba\u7cbe\u5bc6\u6d4b\u91cf\u6a21\u578b\u62a5\u544a\uff08\u901a\u8fc7\u4e13\u5bb6\u8bc4\u5ba1\uff09'],
        ['M2\uff1a\u4e13\u5229\u63d0\u4ea4\u8fbe6\u9879', '2027\u5e743\u6708', '6\u9879\u53d1\u660e\u4e13\u5229\u53d7\u7406\u901a\u77e5\u4e66'],
        ['M3\uff1a\u566a\u58f0\u6291\u5236\u9a8c\u8bc1\u5b8c\u6210', '2027\u5e746\u6708', '\u566a\u58f0\u6291\u5236\u6548\u679c\u7efc\u5408\u62a5\u544a'],
        ['M4\uff1a\u8bba\u6587\u5f55\u7528\u8fbe6\u7bc7', '2027\u5e749\u6708', '6\u7bc7\u8bba\u6587\u5f55\u7528/\u68c0\u7d22\u8bc1\u660e'],
        ['M5\uff1a\u7ed3\u9898\u6d4b\u8bd5\u901a\u8fc7', '2027\u5e749\u6708', '\u7ed3\u9898\u6d4b\u8bd5\u62a5\u544a\uff08\u4e13\u5bb6\u8bc4\u5ba1\u901a\u8fc7\uff09'],
        ['M6\uff1a\u6b63\u5f0f\u7ed3\u9898', '2027\u5e7411\u6708', '\u5168\u5957\u7ed3\u9898\u9a8c\u6536\u6750\u6599'],
    ],
    '\u9636\u6bb5\u6027\u91cc\u7a0b\u7891'
)

# ===== 5 =====
make_heading(1, '\u98ce\u9669\u5206\u6790\u4e0e\u5e94\u5bf9\u63aa\u65bd', 0)
make_body('\u4e0b\u4e00\u9636\u6bb5\u53ef\u80fd\u9762\u4e34\u7684\u4e3b\u8981\u98ce\u9669\u53ca\u5e94\u5bf9\u63aa\u65bd\u89c1\u88683\u3002')
add_table_with_caption(
    ['\u98ce\u9669\u9879', '\u98ce\u9669\u7b49\u7ea7', '\u5e94\u5bf9\u63aa\u65bd'],
    [
        ['\u8bfe\u98985\u539f\u7406\u6837\u673a\u6d4b\u8bd5\u6570\u636e\u4e0e\u4eff\u771f\u7ed3\u679c\u504f\u5dee>10%', '\u4e2d\u7b49', '\u63d0\u524d\u4e0e\u8bfe\u98985\u5efa\u7acb\u5e38\u6001\u5316\u6bd4\u5bf9\u673a\u5236\uff0c\u9884\u75593\u4e2a\u6708\u6a21\u578b\u8fed\u4ee3\u7a97\u53e3'],
        ['\u8bba\u6587\u5ba1\u7a3f\u5468\u671f\u4e0d\u53ef\u63a7', '\u4e2d\u7b49', '\u4f18\u5148\u6295\u9012\u9ad8\u5206\u533a\u671f\u520a\uff0c\u5408\u7406\u89c4\u5212\u63d0\u524d6\u4e2a\u6708\u4ee5\u4e0a\u6295\u7a3f\uff1b\u9884\u7559\u5907\u9009\u671f\u520a'],
        ['\u4e13\u5229\u5ba1\u67e5\u5468\u671f\u957f', '\u4f4e', '\u5df2\u63d0\u524d\u5e03\u5c40\uff0c\u4e2d\u671f\u5373\u6709\u5b9e\u8d28\u6027\u5ba1\u67e5\u8fdb\u5c55'],
        ['\u6b7b\u533a\u8bef\u5dee\u5b9e\u6d4b\u9a8c\u8bc1\u6761\u4ef6\u590d\u6742', '\u4f4e', '\u6b7b\u533a\u6a21\u578b\u5df2\u8d85\u524d\u5b8c\u6210\uff0c\u5229\u7528\u73b0\u6709\u6d4b\u8bd5\u94fe\u8def\u9a8c\u8bc1\u5373\u53ef'],
        ['\u9879\u76ee\u4eba\u5458\u53d8\u52a8', '\u4e2d\u7b49', '\u5efa\u7acb\u6587\u6863\u5316\u4ea4\u63a5\u673a\u5236\uff0c\u6838\u5fc3\u6a21\u578b\u548c\u4ee3\u7801\u89c4\u8303\u7ba1\u7406'],
    ],
    '\u98ce\u9669\u5206\u6790\u4e0e\u5e94\u5bf9\u63aa\u65bd'
)

# ===== 6 =====
make_heading(1, '\u7ecf\u8d39\u4f7f\u7528\u8ba1\u5212\uff08\u4e0b\u4e00\u9636\u6bb5\uff09', 0)
make_body('\u4e0b\u4e00\u9636\u6bb5\u7ecf\u8d39\u4f7f\u7528\u8ba1\u5212\u89c1\u88684\u3002')
add_table_with_caption(
    ['\u7ecf\u8d39\u7c7b\u522b', '\u9884\u7b97\uff08\u4e07\u5143\uff09', '\u4e3b\u8981\u7528\u9014'],
    [
        ['\u8bbe\u5907\u8d39', '\u2014', '\u5229\u7528\u73b0\u6709\u8bbe\u5907\uff0c\u65e0\u9700\u65b0\u589e'],
        ['\u6750\u6599\u8d39', '\uff08\u6309\u4efb\u52a1\u4e66\u9884\u7b97\u6267\u884c\uff09', '\u6d4b\u8bd5\u76f8\u5173\u8017\u6750'],
        ['\u6d4b\u8bd5/\u5b9e\u9a8c\u8d39', '\uff08\u6309\u4efb\u52a1\u4e66\u9884\u7b97\u6267\u884c\uff09', '\u7ed3\u9898\u6d4b\u8bd5\u3001\u4e13\u5bb6\u8bc4\u5ba1'],
        ['\u51fa\u7248/\u6587\u732e/\u77e5\u8bc6\u4ea7\u6743\u8d39', '\uff08\u6309\u4efb\u52a1\u4e66\u9884\u7b97\u6267\u884c\uff09', '\u8bba\u6587\u7248\u9762\u8d39\u3001\u4e13\u5229\u7533\u8bf7\u8d39'],
        ['\u5176\u4ed6', '\uff08\u6309\u4efb\u52a1\u4e66\u9884\u7b97\u6267\u884c\uff09', '\u5dee\u65c5\u3001\u4f1a\u8bae'],
    ],
    '\u7ecf\u8d39\u4f7f\u7528\u8ba1\u5212'
)

make_body('')
make_body('\u7f16\u5236\u65e5\u671f\uff1a2026\u5e746\u6708', align=WD_ALIGN_PARAGRAPH.RIGHT, indent=False)

# ---- Save ----
out_path = r'E:\Codex_Projects\重点研发项目相关\中期\技术类\8.项目下一阶段工作计划\项目下一阶段工作计划.docx'
doc.save(out_path)
print(f'Saved: {out_path}')
print(f'Size: {os.path.getsize(out_path)} bytes')
