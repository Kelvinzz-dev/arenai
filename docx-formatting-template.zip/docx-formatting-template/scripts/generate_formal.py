#!/usr/bin/env python
"""Generate 项目下一阶段工作计划.docx following the official 提纲 format."""
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from copy import deepcopy
import os

doc = Document()

# ---- Page margins ----
for section in doc.sections:
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(3.17)
    section.right_margin = Cm(3.17)

# ---- Font helper ----
def set_run_font(run, cn_font='\u5b8b\u4f53', en_font='Times New Roman',
                 size=Pt(12), bold=False):
    run.font.size = size
    run.font.name = en_font
    run.font.bold = bold
    rpr = run._element.get_or_add_rPr()
    rpr.rFonts.set(qn('w:eastAsia'), cn_font)
    color_elem = rpr.find(qn('w:color'))
    if color_elem is None:
        color_elem = OxmlElement('w:color')
        rpr.append(color_elem)
    color_elem.set(qn('w:val'), '000000')
    color_elem.set(qn('w:themeColor'), 'text1')

# ---- Multi-level list numbering ----
def get_or_create_numbering_id(doc):
    numbering_part = doc.part.numbering_part
    numbering_xml = numbering_part._element
    max_abs_id = 0
    for an in numbering_xml.findall(qn('w:abstractNum')):
        aid = int(an.get(qn('w:abstractNumId')))
        if aid >= max_abs_id: max_abs_id = aid
    abs_num_id = max_abs_id + 1
    abstract_num = OxmlElement('w:abstractNum')
    abstract_num.set(qn('w:abstractNumId'), str(abs_num_id))
    for ilvl, fmt in enumerate(['%1.', '%1.%2', '%1.%2.%3', '%1.%2.%3.%4', '%1.%2.%3.%4.%5', '%1.%2.%3.%4.%5.%6']):
        lvl = OxmlElement('w:lvl')
        lvl.set(qn('w:ilvl'), str(ilvl))
        lvl_fmt = OxmlElement('w:numFmt')
        lvl_fmt.set(qn('w:val'), 'decimal')
        lvl.append(lvl_fmt)
        lvl_lvlText = OxmlElement('w:lvlText')
        lvl_lvlText.set(qn('w:val'), fmt)
        lvl.append(lvl_lvlText)
        lvl_start = OxmlElement('w:start')
        lvl_start.set(qn('w:val'), '1')
        lvl.append(lvl_start)
        lvl_just = OxmlElement('w:lvlJc')
        lvl_just.set(qn('w:val'), 'left')
        lvl.append(lvl_just)
        lvl_suff = OxmlElement('w:suff')
        lvl_suff.set(qn('w:val'), 'space')
        lvl.append(lvl_suff)
        size_map = {0: 32, 1: 28, 2: 24, 3: 24, 4: 24, 5: 24}
        cn_font_map = {0: '\u9ed1\u4f53', 1: '\u5b8b\u4f53', 2: '\u5b8b\u4f53', 3: '\u5b8b\u4f53', 4: '\u5b8b\u4f53', 5: '\u5b8b\u4f53'}
        bold_map = {0: False, 1: True, 2: True, 3: True, 4: True, 5: True}
        lvl_rPr = OxmlElement('w:rPr')
        lvl_rFonts = OxmlElement('w:rFonts')
        lvl_rFonts.set(qn('w:ascii'), 'Times New Roman')
        lvl_rFonts.set(qn('w:hAnsi'), 'Times New Roman')
        lvl_rFonts.set(qn('w:eastAsia'), cn_font_map[ilvl])
        lvl_rPr.append(lvl_rFonts)
        lvl_color = OxmlElement('w:color')
        lvl_color.set(qn('w:val'), '000000')
        lvl_rPr.append(lvl_color)
        lvl_sz = OxmlElement('w:sz')
        lvl_sz.set(qn('w:val'), str(size_map[ilvl]))
        lvl_rPr.append(lvl_sz)
        lvl_szCs = OxmlElement('w:szCs')
        lvl_szCs.set(qn('w:val'), str(size_map[ilvl]))
        lvl_rPr.append(lvl_szCs)
        if bold_map[ilvl]:
            lvl_b = OxmlElement('w:b')
            lvl_rPr.append(lvl_b)
        lvl.append(lvl_rPr)
        lvl_pPr = OxmlElement('w:pPr')
        lvl_ind = OxmlElement('w:ind')
        lvl_ind.set(qn('w:left'), '0')
        lvl_ind.set(qn('w:hanging'), '0')
        lvl_pPr.append(lvl_ind)
        lvl.append(lvl_pPr)
        abstract_num.append(lvl)
    numbering_xml.append(abstract_num)
    max_num_id = 0
    for n in numbering_xml.findall(qn('w:num')):
        nid = int(n.get(qn('w:numId')))
        if nid >= max_num_id: max_num_id = nid
    num_id = max_num_id + 1
    num_elem = OxmlElement('w:num')
    num_elem.set(qn('w:numId'), str(num_id))
    abs_ref = OxmlElement('w:abstractNumId')
    abs_ref.set(qn('w:val'), str(abs_num_id))
    num_elem.append(abs_ref)
    numbering_xml.append(num_elem)
    return num_id

NUM_ID = get_or_create_numbering_id(doc)

# ---- Body paragraph ----
def make_body(text, align=WD_ALIGN_PARAGRAPH.JUSTIFY, indent=True):
    p = doc.add_paragraph()
    run = p.add_run(text)
    set_run_font(run, size=Pt(12), bold=False)
    pf = p.paragraph_format
    pf.alignment = align
    pf.first_line_indent = Pt(24) if indent else Pt(0)
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    return p

# ---- Heading ----
def make_heading(level, text, ilvl):
    style_map = {1: 'Heading 1', 2: 'Heading 2', 3: 'Heading 3'}
    p = doc.add_paragraph()
    p.style = doc.styles[style_map[level]]
    p.clear()
    pPr = p._element.get_or_add_pPr()
    numPr = OxmlElement('w:numPr')
    numId_el = OxmlElement('w:numId')
    numId_el.set(qn('w:val'), str(NUM_ID))
    numPr.append(numId_el)
    ilvl_el = OxmlElement('w:ilvl')
    ilvl_el.set(qn('w:val'), str(ilvl))
    numPr.append(ilvl_el)
    pPr.append(numPr)
    for old in pPr.findall(qn('w:ind')): pPr.remove(old)
    for old in pPr.findall(qn('w:spacing')): pPr.remove(old)
    for old in pPr.findall(qn('w:jc')): pPr.remove(old)
    spacing = OxmlElement('w:spacing')
    spacing.set(qn('w:before'), '0')
    spacing.set(qn('w:after'), '0')
    spacing.set(qn('w:line'), '360')
    spacing.set(qn('w:lineRule'), 'auto')
    pPr.append(spacing)
    jc = OxmlElement('w:jc')
    jc.set(qn('w:val'), 'left')
    pPr.append(jc)
    run = p.add_run(text)
    if level == 1:
        set_run_font(run, cn_font='\u9ed1\u4f53', size=Pt(16), bold=False)
    elif level == 2:
        set_run_font(run, size=Pt(14), bold=True)
    else:
        set_run_font(run, size=Pt(12), bold=True)
    return p

# ---- Table with caption ----
_table_seq = [0]
def _add_seq_field(paragraph, label):
    _table_seq[0] += 1
    def make_r():
        r = OxmlElement('w:r')
        rpr = OxmlElement('w:rPr')
        rFonts = OxmlElement('w:rFonts')
        rFonts.set(qn('w:ascii'), 'Times New Roman')
        rFonts.set(qn('w:hAnsi'), 'Times New Roman')
        rFonts.set(qn('w:eastAsia'), '\u5b8b\u4f53')
        rpr.append(rFonts)
        color_e = OxmlElement('w:color')
        color_e.set(qn('w:val'), '000000')
        color_e.set(qn('w:themeColor'), 'text1')
        rpr.append(color_e)
        sz = OxmlElement('w:sz')
        sz.set(qn('w:val'), '24')
        rpr.append(sz)
        szCs = OxmlElement('w:szCs')
        szCs.set(qn('w:val'), '24')
        rpr.append(szCs)
        r.append(rpr)
        return r
    rb = make_r(); fc = OxmlElement('w:fldChar'); fc.set(qn('w:fldCharType'), 'begin'); rb.append(fc); paragraph._element.append(rb)
    ri = make_r(); it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = f' SEQ {label} \\\\* ARABIC'; ri.append(it); paragraph._element.append(ri)
    rs = make_r(); fcs = OxmlElement('w:fldChar'); fcs.set(qn('w:fldCharType'), 'separate'); rs.append(fcs); paragraph._element.append(rs)
    rd = make_r(); dt = OxmlElement('w:t'); dt.text = str(_table_seq[0]); rd.append(dt); paragraph._element.append(rd)
    re = make_r(); fce = OxmlElement('w:fldChar'); fce.set(qn('w:fldCharType'), 'end'); re.append(fce); paragraph._element.append(re)

def add_table_with_caption(headers, rows, caption_text):
    cap_p = doc.add_paragraph()
    cap_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pf = cap_p.paragraph_format
    pf.space_before = Pt(0); pf.space_after = Pt(0)
    pf.first_line_indent = Pt(0)
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE; pf.line_spacing = 1.5
    r0 = cap_p.add_run('\u8868'); set_run_font(r0, size=Pt(12), bold=False)
    _add_seq_field(cap_p, '\u8868')
    r2 = cap_p.add_run('  ' + caption_text); set_run_font(r2, size=Pt(12), bold=False)
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]; cell.text = ''; p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.first_line_indent = Pt(0); p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
        r = p.add_run(h); set_run_font(r, size=Pt(10.5), bold=True)
    for ri, row in enumerate(rows):
        for ci, val in enumerate(row):
            cell = table.rows[ri + 1].cells[ci]; cell.text = ''; p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.first_line_indent = Pt(0); p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            r = p.add_run(str(val)); set_run_font(r, size=Pt(10.5), bold=False)
    table.autofit = True
    tbl = table._tbl; tblPr = tbl.find(qn('w:tblPr'))
    if tblPr is None: tblPr = OxmlElement('w:tblPr'); tbl.insert(0, tblPr)
    layout = tblPr.find(qn('w:tblLayout'))
    if layout is None: layout = OxmlElement('w:tblLayout'); tblPr.append(layout)
    layout.set(qn('w:type'), 'autofit')
    tblW = tblPr.find(qn('w:tblW'))
    if tblW is None: tblW = OxmlElement('w:tblW'); tblPr.append(tblW)
    tblW.set(qn('w:type'), 'pct'); tblW.set(qn('w:w'), '5000')
    for row_obj in table.rows:
        for cell_obj in row_obj.cells:
            tc = cell_obj._tc; tcPr = tc.find(qn('w:tcPr'))
            if tcPr is None: tcPr = OxmlElement('w:tcPr'); tc.insert(0, tcPr)
            vAlign = OxmlElement('w:vAlign'); vAlign.set(qn('w:val'), 'center'); tcPr.append(vAlign)
    sp = doc.add_paragraph()
    sp.paragraph_format.space_before = Pt(0); sp.paragraph_format.space_after = Pt(0)
    sp.paragraph_format.first_line_indent = Pt(0)
    sp.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE; sp.paragraph_format.line_spacing = 1.5
    return table

# ============================================================
# DOCUMENT CONTENT
# ============================================================

# ---- Title Block ----
def add_info_line(label, value):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.first_line_indent = Pt(0)
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    p.paragraph_format.line_spacing = 1.5
    r1 = p.add_run(label)
    set_run_font(r1, size=Pt(14), bold=True)
    # Check if we need a second line for value
    if value:
        r2 = p.add_run(value)
        set_run_font(r2, size=Pt(14), bold=False)

main_title_p = doc.add_paragraph()
main_title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
main_title_p.paragraph_format.space_before = Pt(6)
main_title_p.paragraph_format.space_after = Pt(6)
main_title_p.paragraph_format.first_line_indent = Pt(0)
main_title_p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
main_title_p.paragraph_format.line_spacing = 1.5
r = main_title_p.add_run('\u9644\u4ef63-4\n\u9879\u76ee\u4e0b\u4e00\u9636\u6bb5\u5de5\u4f5c\u8ba1\u5212\n\uff08\u63d0\u7eb2\uff09')
set_run_font(r, cn_font='\u9ed1\u4f53', size=Pt(18), bold=True)

doc.add_paragraph()

# Project info (not numbered, centered)
for label, val in [
    ('项目编号：', '2024YFB3212701'),
    ('项目名称：', '高稳定微型硅光陀螺敏感元件及传感器'),
    ('项目牵头单位：', '浙江大学'),
    ('项目负责人：', '陈杏藩'),
]:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.first_line_indent = Pt(0)
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    p.paragraph_format.line_spacing = 1.5
    r1 = p.add_run(label)
    set_run_font(r1, size=Pt(14), bold=True)
    r2 = p.add_run(val)
    set_run_font(r2, size=Pt(14), bold=False)

doc.add_paragraph()

# ============================================================
# 一、任务书中待完成的研究内容、目标和考核指标
# ============================================================
make_heading(1, '\u4efb\u52a1\u4e66\u4e2d\u5f85\u5b8c\u6210\u7684\u7814\u7a76\u5185\u5bb9\u3001\u76ee\u6807\u548c\u8003\u6838\u6307\u6807', 0)
make_body('\u6839\u636e\u8bfe\u9898\u4efb\u52a1\u4e66\u7ea6\u5b9a\uff0c\u8bfe\u98981\uff08\u57fa\u4e8e\u7845\u5149\u6280\u672f\u7684\u9ad8\u7cbe\u5ea6\u89d2\u901f\u5ea6\u6d4b\u91cf\u7406\u8bba\uff09\u5728\u5269\u4f59\u6267\u884c\u671f\u5185\uff082026\u5e746\u6708\u81f32027\u5e7411\u6708\uff09\u5f85\u5b8c\u6210\u7684\u4e3b\u8981\u7814\u7a76\u5185\u5bb9\u3001\u76ee\u6807\u53ca\u8003\u6838\u6307\u6807\u5982\u4e0b\uff1a')

add_table_with_caption(
    ['\u5e8f\u53f7', '\u7814\u7a76\u5185\u5bb9', '\u76ee\u6807\u4e0e\u8003\u6838\u6307\u6807', '\u5b8c\u6210\u65f6\u95f4'],
    [
        ['1', '\u5fae\u578b\u7845\u5149\u9640\u87ba\u7cbe\u5bc6\u6d4b\u91cf\u6a21\u578b\u4eff\u771f\u8f6f\u4ef6\u5b8c\u5584',
         '\u53ef\u4eff\u771f7\u79cd\u8bef\u5dee\u7c7b\u522b\uff0c\u901a\u8fc7\u4e13\u5bb6\u73b0\u573a\u6d4b\u8bd5', '2027\u5e749\u6708'],
        ['2', '\u6a21\u578b\u4eff\u771f\u7ed3\u679c\u4e0e\u5b9e\u6d4b\u6570\u636e\u4e00\u81f4\u6027\u9a8c\u8bc1',
         '\u4eff\u771f\u7ed3\u679c\u4e0e\u8bfe\u98985\u5b9e\u6d4b\u7ed3\u679c\u76f8\u5bf9\u8bef\u5dee\u226410%', '2027\u5e749\u6708'],
        ['3', '\u5fae\u578b\u7845\u5149\u9640\u87ba\u7cbe\u5bc6\u6d4b\u91cf\u6a21\u578b\u62a5\u544a',
         '1\u4efd\u62a5\u544a\u6b63\u6587\u901a\u8fc7\u4e13\u5bb6\u8bc4\u5ba1', '2026\u5e7412\u6708'],
        ['4', '\u566a\u58f0\u5206\u6790\u53ca\u6291\u5236\u62a5\u544a',
         '1\u4efd\u62a5\u544a\u6b63\u6587\u901a\u8fc7\u4e13\u5bb6\u8bc4\u5ba1', '\u5df2\u5b8c\u6210\uff08\u4e2d\u671f\uff09'],
        ['5', '\u53d1\u660e\u4e13\u5229',
         '\u4e0d\u5c11\u4e8e6\u9879\u53d1\u660e\u4e13\u5229\u53d7\u7406/\u6388\u6743', '2027\u5e743\u6708\u524d'],
        ['6', 'SCI\u6216EI\u6216\u6838\u5fc3\u8bba\u6587',
         '\u4e0d\u5c11\u4e8e6\u7bc7\u8bba\u6587\u5f55\u7528/\u68c0\u7d22', '2027\u5e749\u6708\u524d'],
        ['7', '\u7814\u7a76\u751f\u57f9\u517b',
         '\u4e0d\u5c11\u4e8e3\u540d\u7814\u7a76\u751f\u57f9\u517b\u5b8c\u6210', '2027\u5e7411\u6708\u524d'],
        ['8', '\u8bfe\u9898\u7ed3\u9898\u9a8c\u6536',
         '\u5168\u90e8\u6307\u6807\u8fbe\u6807\uff0c\u901a\u8fc7\u7ed3\u9898\u9a8c\u6536', '2027\u5e7411\u6708'],
    ],
    '\u5f85\u5b8c\u6210\u7684\u7814\u7a76\u5185\u5bb9\u3001\u76ee\u6807\u548c\u8003\u6838\u6307\u6807'
)

make_body('\u5176\u4e2d\uff0c\u7b2c4\u9879\u566a\u58f0\u5206\u6790\u53ca\u6291\u5236\u62a5\u544a\u5df2\u5728\u4e2d\u671f\u68c0\u67e5\u524d\u5b8c\u6210\uff0c\u5176\u4f59\u6307\u6807\u5747\u5728\u63a8\u8fdb\u4e2d\u3002')

# ============================================================
# 二、任务书研究内容完成情况
# ============================================================
make_heading(1, '\u4efb\u52a1\u4e66\u7814\u7a76\u5185\u5bb9\u5b8c\u6210\u60c5\u51b5', 0)
make_body('\u622a\u81f3\u4e2d\u671f\u68c0\u67e5\u8282\u70b9\uff082026\u5e746\u6708\uff09\uff0c\u8bfe\u9898\u5404\u9879\u7814\u7a76\u5185\u5bb9\u5b8c\u6210\u60c5\u51b5\u5982\u4e0b\uff1a')

add_table_with_caption(
    ['\u5e8f\u53f7', '\u7814\u7a76\u5185\u5bb9', '\u5bf9\u5e94\u8003\u6838\u6307\u6807', '\u5b8c\u6210\u60c5\u51b5', '\u4e3b\u8981\u5dee\u8ddd\u4e0e\u540e\u7eed\u5de5\u4f5c'],
    [
        ['1', '\u4eff\u771f\u8f6f\u4ef6\u5f00\u53d1\uff086\u79cd\u8bef\u5dee\u7c7b\u522b\uff09', '\u53ef\u4eff\u771f6\u79cd\u8bef\u5dee\u7c7b\u522b',
         '\u2705 \u5df2\u5b8c\u6210\uff0c\u901a\u8fc7\u4e13\u5bb6\u73b0\u573a\u6d4b\u8bd5', '\u5df2\u8d85\u524d\u5b8c\u6210\u6b7b\u533a\u8bef\u5dee\u6a21\u5757\uff0c\u53ef\u4eff\u771f7\u79cd'],
        ['2', '\u4eff\u771f\u7ed3\u679c\u4e0e\u8bfe\u98985\u4e00\u81f4\u6027\u9a8c\u8bc1', '\u76f8\u5bf9\u8bef\u5dee\u226410%',
         '\u8fdb\u884c\u4e2d', '\u5f85\u8bfe\u98985\u539f\u7406\u6837\u673a\u5b9e\u6d4b\u6570\u636e\u5b8c\u6210\u540e\u5f00\u5c55\u6bd4\u5bf9'],
        ['3', '\u7cbe\u5bc6\u6d4b\u91cf\u6a21\u578b\u62a5\u544a', '1\u4efd\u62a5\u544a\u901a\u8fc7\u8bc4\u5ba1',
         '\u8fdb\u884c\u4e2d', '\u8ba1\u52122026\u5e7412\u6708\u524d\u5b8c\u6210\u5e76\u901a\u8fc7\u8bc4\u5ba1'],
        ['4', '\u566a\u58f0\u5206\u6790\u53ca\u6291\u5236\u62a5\u544a', '1\u4efd\u62a5\u544a\u901a\u8fc7\u8bc4\u5ba1',
         '\u2705 \u5df2\u5b8c\u6210', '\u65e0'],
        ['5', '\u53d1\u660e\u4e13\u5229', '\u22656\u9879',
         '\u90e8\u5206\u5b8c\u6210', '\u5df2\u63d0\u4ea41\u9879\uff08\u5b9e\u8d28\u5ba1\u67e5\u4e2d\uff09\uff0c\u8ba1\u5212\u518d\u63d0\u4ea45\u9879'],
        ['6', 'SCI/EI/\u6838\u5fc3\u8bba\u6587', '\u22656\u7bc7',
         '\u8fdb\u884c\u4e2d', '\u8ba1\u5212\u5206\u522b\u57282026.9\u30012026.12\u30012027.3\u30012027.6\u30012027.9\u6295\u7a3f'],
        ['7', '\u7814\u7a76\u751f\u57f9\u517b', '\u22653\u540d',
         '\u8fdb\u884c\u4e2d', '\u786e\u4fdd\u6bd5\u4e1a\u65f6\u95f4\u4e0d\u665a\u4e8e2027\u5e7411\u6708'],
    ],
    '\u4efb\u52a1\u4e66\u7814\u7a76\u5185\u5bb9\u5b8c\u6210\u60c5\u51b5'
)

make_body('\u7efc\u4e0a\uff0c\u8bfe\u9898\u4e2d\u671f\u7814\u7a76\u4efb\u52a1\u5df2\u5168\u90e8\u5b8c\u6210\uff0c\u90e8\u5206\u7ed3\u9898\u6307\u6807\u5df2\u8d85\u524d\u5b8c\u6210\uff08\u6b7b\u533a\u8bef\u5dee\u6a21\u578b\u3001\u566a\u58f0\u5206\u6790\u53ca\u6291\u5236\u62a5\u544a\uff09\uff0c\u5269\u4f59\u6307\u6807\u6b63\u6309\u8ba1\u5212\u63a8\u8fdb\u4e2d\u3002')

# ============================================================
# 三、保障完成项目任务的具体措施
# ============================================================
make_heading(1, '\u4fdd\u969c\u5b8c\u6210\u9879\u76ee\u4efb\u52a1\u7814\u7a76\u76ee\u6807\u3001\u5185\u5bb9\u548c\u6307\u6807\u7684\u5177\u4f53\u63aa\u65bd', 0)

# --- 3.1 误差模型精度验证 ---
make_heading(2, '\u8bef\u5dee\u6a21\u578b\u7cbe\u5ea6\u9a8c\u8bc1\u4e0e\u4f18\u5316', 1)
add_table_with_caption(
    ['\u5177\u4f53\u63aa\u65bd', '\u65f6\u95f4\u5b89\u6392', '\u6807\u5fd7\u6027\u8282\u70b9', '\u8d23\u4efb\u4e3b\u4f53'],
    [
        ['\u4e0e\u8bfe\u98985\u5bf9\u63a5\uff0c\u83b7\u53d6\u539f\u7406\u6837\u673a\u5b9e\u6d4b\u6570\u636e', '2026\u5e747\u6708', '\u5b9e\u6d4b\u6570\u636e\u6e05\u5355', '\u8bfe\u9898\u7ec4'],
        ['\u57fa\u4e8e\u5b9e\u6d4b\u6570\u636e\u8fdb\u884c\u6a21\u578b\u6821\u51c6', '2026\u5e748\u6708\uff5e9\u6708', '\u6821\u51c6\u8bb0\u5f55', '\u8bfe\u9898\u7ec4'],
        ['\u5f00\u5c557\u79cd\u8bef\u5dee\u7c7b\u522b\u7684\u4eff\u771f-\u5b9e\u6d4b\u6bd4\u5bf9\u9a8c\u8bc1', '2026\u5e7410\u6708\uff5e11\u6708', '\u6bd4\u5bf9\u5206\u6790\u62a5\u544a', '\u8bfe\u9898\u7ec4'],
        ['\u8fed\u4ee3\u4f18\u5316\u6a21\u578b\u7b97\u6cd5\uff08\u5982\u9700\uff09', '2026\u5e7411\u6708\uff5e12\u6708', '\u4f18\u5316\u540e\u7684\u6a21\u578b', '\u8bfe\u9898\u7ec4'],
        ['\u5b8c\u6210\u7cbe\u5bc6\u6d4b\u91cf\u6a21\u578b\u62a5\u544a', '2026\u5e7412\u6708', '\u62a5\u544a\u901a\u8fc7\u4e13\u5bb6\u8bc4\u5ba1', '\u8bfe\u9898\u7ec4'],
    ],
    '\u8bef\u5dee\u6a21\u578b\u7cbe\u5ea6\u9a8c\u8bc1\u4e0e\u4f18\u5316\u63aa\u65bd'
)

# --- 3.2 噪声抑制 ---
make_heading(2, '\u566a\u58f0\u6291\u5236\u65b9\u6cd5\u5de5\u7a0b\u5316\u9a8c\u8bc1', 1)
add_table_with_caption(
    ['\u5177\u4f53\u63aa\u65bd', '\u65f6\u95f4\u5b89\u6392', '\u6807\u5fd7\u6027\u8282\u70b9', '\u8d23\u4efb\u4e3b\u4f53'],
    [
        ['\u6563\u7c92\u566a\u58f0\u3001\u70ed\u566a\u58f0\u3001RIN\u6291\u5236\u65b9\u6848\u5b9e\u65bd\u4e0e\u9a8c\u8bc1', '2026\u5e747\u6708\uff5e9\u6708', '\u6d4b\u8bd5\u6570\u636e', '\u8bfe\u9898\u7ec4'],
        ['\u504f\u632f\u8026\u5408\u6291\u5236\u65b9\u6848\u5b9e\u65bd\u4e0e\u9a8c\u8bc1', '2026\u5e7410\u6708\uff5e12\u6708', '\u6d4b\u8bd5\u6570\u636e', '\u8bfe\u9898\u7ec4'],
        ['\u80cc\u5411\u6563\u5c04\u6291\u5236\u65b9\u6848\u5b9e\u65bd\u4e0e\u9a8c\u8bc1', '2027\u5e741\u6708\uff5e3\u6708', '\u6d4b\u8bd5\u6570\u636e', '\u8bfe\u9898\u7ec4'],
        ['\u514b\u5c14\u6548\u5e94\u6291\u5236\u65b9\u6848\u5b9e\u65bd\u4e0e\u9a8c\u8bc1', '2027\u5e744\u6708\uff5e6\u6708', '\u6d4b\u8bd5\u6570\u636e', '\u8bfe\u9898\u7ec4'],
        ['\u6c47\u603b\u566a\u58f0\u6291\u5236\u6548\u679c\u8bc4\u4f30\u62a5\u544a', '2027\u5e746\u6708', '\u566a\u58f0\u6291\u5236\u6548\u679c\u7efc\u5408\u62a5\u544a', '\u8bfe\u9898\u7ec4'],
    ],
    '\u566a\u58f0\u6291\u5236\u65b9\u6cd5\u5de5\u7a0b\u5316\u9a8c\u8bc1\u63aa\u65bd'
)

# --- 3.3 科研成果 ---
make_heading(2, '\u79d1\u7814\u6210\u679c\u4ea7\u51fa\u4e0e\u77e5\u8bc6\u4ea7\u6743\u5e03\u5c40', 1)
make_body('\uff081\uff09\u53d1\u660e\u4e13\u5229\uff1a\u5728\u5df2\u63d0\u4ea4\u76841\u9879\u57fa\u7840\u4e0a\uff0c\u56f4\u7ed5\u504f\u632f\u8026\u5408\u6291\u5236\u3001\u80cc\u5411\u6563\u5c04\u6291\u5236\u3001\u6b7b\u533a\u8bef\u5dee\u8865\u507f\u3001\u7845\u5149\u9640\u87ba\u7cfb\u7edf\u8bbe\u8ba1\u4f18\u5316\u3001\u4eff\u771f\u65b9\u6cd5\u7b49\u65b9\u5411\u7ee7\u7eed\u5e03\u5c40\u4e13\u5229\uff0c\u8ba1\u52122026\u5e749\u6708\u524d\u518d\u63d0\u4ea42\uff5e3\u9879\uff0c2027\u5e743\u6708\u524d\u5b8c\u6210\u5168\u90e8\u22656\u9879\u7684\u63d0\u4ea4\u3002', indent=True)
make_body('\uff082\uff09\u5b66\u672f\u8bba\u6587\uff1a\u7ed3\u5408\u8bfe\u9898\u7814\u7a76\u5185\u5bb9\uff0c\u8ba1\u5212\u5728\u5bbd\u8c31\u5149\u6e90\u76f8\u5bf9\u5f3a\u5ea6\u566a\u58f0\u3001\u504f\u632f\u8026\u5408\u8bef\u5dee\u3001\u80cc\u5411\u6563\u5c04\u566a\u58f0\u3001\u6b7b\u533a\u6548\u5e94\u3001\u514b\u5c14\u6548\u5e94\u3001\u591a\u6e90\u8bef\u5dee\u8026\u5408\u5efa\u6a21\u7b496\u4e2a\u65b9\u5411\u5206\u522b\u6295\u7a3f\uff0c\u76ee\u6807\u671f\u520a\u5305\u62ecOptics Express\u3001Journal of Lightwave Technology\u3001IEEE Photonics Journal\u3001\u5149\u5b66\u7cbe\u5bc6\u5de5\u7a0b\u7b49\u3002\u7b2c\u4e00\u7bc7\u8ba1\u52122026\u5e749\u6708\u5b8c\u6210\u6295\u7a3f\uff0c\u6bcf\u5b63\u5ea6\u81f3\u5c11\u6295\u7a3f1\u7bc7\u3002', indent=True)
make_body('\uff083\uff09\u7814\u7a76\u751f\u57f9\u517b\uff1a\u786e\u4fdd\u22653\u540d\u535a\u58eb\u751f\u6309\u8ba1\u5212\u5b8c\u6210\u8bba\u6587\u5e76\u6bd5\u4e1a\uff0c\u5efa\u7acb\u5b9a\u671f\u6c47\u62a5\u673a\u5236\uff0c\u6838\u5fc3\u6a21\u578b\u548c\u4ee3\u7801\u89c4\u8303\u7ba1\u7406\u3002', indent=True)

# --- 3.4 结题测试 ---
make_heading(2, '\u4eff\u771f\u8f6f\u4ef6\u529f\u80fd\u5b8c\u5584\u4e0e\u7ed3\u9898\u6d4b\u8bd5', 1)
add_table_with_caption(
    ['\u5177\u4f53\u63aa\u65bd', '\u65f6\u95f4\u5b89\u6392', '\u6807\u5fd7\u6027\u8282\u70b9', '\u8d23\u4efb\u4e3b\u4f53'],
    [
        ['\u5b8c\u5584\u4eff\u771f\u8f6f\u4ef6\u754c\u9762\u4e0e\u7528\u6237\u4f53\u9a8c', '2027\u5e747\u6708', '\u66f4\u65b0\u540e\u7684\u4eff\u771f\u8f6f\u4ef6', '\u8bfe\u9898\u7ec4'],
        ['\u7f16\u5199\u7ed3\u9898\u6d4b\u8bd5\u62a5\u544a', '2027\u5e748\u6708', '\u7ed3\u9898\u6d4b\u8bd5\u62a5\u544a', '\u8bfe\u9898\u7ec4'],
        ['\u914d\u5408\u4e13\u5bb6\u73b0\u573a\u6d4b\u8bd5', '2027\u5e749\u6708', '\u73b0\u573a\u6d4b\u8bd5\u8bb0\u5f55', '\u8bfe\u9898\u7ec4'],
        ['\u5b8c\u6210\u7ed3\u9898\u9a8c\u6536\u6750\u6599\u6c47\u603b', '2027\u5e7410\u6708', '\u5168\u90e8\u7ed3\u9898\u6750\u6599', '\u8bfe\u9898\u7ec4'],
    ],
    '\u4eff\u771f\u8f6f\u4ef6\u529f\u80fd\u5b8c\u5584\u4e0e\u7ed3\u9898\u6d4b\u8bd5\u63aa\u65bd'
)

# --- 3.5 结题验收 ---
make_heading(2, '\u7ed3\u9898\u9a8c\u6536\u51c6\u5907', 1)
add_table_with_caption(
    ['\u5177\u4f53\u63aa\u65bd', '\u65f6\u95f4\u5b89\u6392', '\u6807\u5fd7\u6027\u8282\u70b9', '\u8d23\u4efb\u4e3b\u4f53'],
    [
        ['\u6c47\u603b\u8bfe\u9898\u6267\u884c\u60c5\u51b5\u62a5\u544a', '2027\u5e7410\u6708', '\u6267\u884c\u60c5\u51b5\u62a5\u544a', '\u8bfe\u9898\u7ec4'],
        ['\u6c47\u603b\u77e5\u8bc6\u4ea7\u6743\u6e05\u5355\uff08\u4e13\u5229/\u8bba\u6587/\u8f6f\u8457\uff09', '2027\u5e7410\u6708', '\u77e5\u8bc6\u4ea7\u6743\u6e05\u5355', '\u8bfe\u9898\u7ec4'],
        ['\u914d\u5408\u8d22\u52a1\u51b3\u7b97\u4e0e\u5ba1\u8ba1', '2027\u5e7410\u6708\uff5e11\u6708', '\u8d22\u52a1\u51b3\u7b97\u62a5\u544a', '\u8bfe\u9898\u7ec4\u3001\u8d22\u52a1\u90e8\u95e8'],
        ['\u7ed3\u9898\u7b54\u8fa9\u51c6\u5907\uff08PPT\u53ca\u5168\u5957\u6750\u6599\uff09', '2027\u5e7411\u6708', '\u7b54\u8fa9PPT', '\u8bfe\u9898\u7ec4'],
    ],
    '\u7ed3\u9898\u9a8c\u6536\u51c6\u5907\u63aa\u65bd'
)

# --- 3.6 风险保障 ---
make_heading(2, '\u98ce\u9669\u9632\u63a7\u4e0e\u8d28\u91cf\u4fdd\u969c', 1)
make_body('\uff081\uff09\u5efa\u7acb\u4e0e\u8bfe\u98985\u7684\u5e38\u6001\u5316\u6bd4\u5bf9\u673a\u5236\uff0c\u786e\u4fdd\u5b9e\u6d4b\u6570\u636e\u53ca\u65f6\u4ea4\u63a5\uff0c\u4e3a\u6a21\u578b\u6821\u51c6\u9884\u7559\u5145\u8db3\u65f6\u95f4\u7a97\u53e3\u3002', indent=True)
make_body('\uff082\uff09\u8bba\u6587\u6295\u7a3f\u91c7\u53d6\u201c\u4e3b\u671f\u520a+\u5907\u9009\u671f\u520a\u201d\u53cc\u901a\u9053\u7b56\u7565\uff0c\u63d0\u524d6\u4e2a\u6708\u4ee5\u4e0a\u5b8c\u6210\u6295\u7a3f\uff0c\u907f\u514d\u5ba1\u7a3f\u5468\u671f\u5f71\u54cd\u7ed3\u9898\u8fdb\u5ea6\u3002', indent=True)
make_body('\uff083\uff09\u4e13\u5229\u5e03\u5c40\u63d0\u524d\u5230\u4f4d\uff0c\u5df2\u6709\u5b9e\u8d28\u6027\u5ba1\u67e5\u8fdb\u5c55\uff0c\u540e\u7eed\u6309\u8ba1\u5212\u7a33\u6b65\u63d0\u4ea4\u3002', indent=True)
make_body('\uff084\uff09\u5efa\u7acb\u6587\u6863\u5316\u4ea4\u63a5\u673a\u5236\uff0c\u6838\u5fc3\u6a21\u578b\u548c\u4ee3\u7801\u89c4\u8303\u7ba1\u7406\uff0c\u786e\u4fdd\u4eba\u5458\u53d8\u52a8\u4e0d\u5f71\u54cd\u9879\u76ee\u8fdb\u5ea6\u3002', indent=True)

# ---- Footer ----
make_body('')
make_body('\u7f16\u5236\u65e5\u671f\uff1a2026\u5e746\u6708', align=WD_ALIGN_PARAGRAPH.RIGHT, indent=False)

# ---- Save ----
out_dir = r'E:\Codex_Projects\重点研发项目相关\中期\技术类\8.项目下一阶段工作计划'
out_path = os.path.join(out_dir, '\u9879\u76ee\u4e0b\u4e00\u9636\u6bb5\u5de5\u4f5c\u8ba1\u5212_\u63d0\u7eb2.docx')
doc.save(out_path)
print(f'Saved: {out_path}')
print(f'Size: {os.path.getsize(out_path)} bytes')
